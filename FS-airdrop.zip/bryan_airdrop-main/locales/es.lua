Locales['es'] = {
    -- Command
    ['command_help'] = 'Desplegar un Suministro Aéreo',
    ['command_args_lootTable'] = 'ID de Botín en la Tabla| No Necesario',
    ['command_error_loottable_not_found'] = '(ID: %s) de Botín No Encontrado en la Tabla',

    -- 3D Text
    ['3d_press_to_pickup'] = 'Presiona [E] para coger el Suministro Aéreo',

    -- Progress Bar
    ['progress_bar_picking_up'] = 'Cogiendo el Suministro Aéreo',

    -- Notification
    ['notification_airdrop_spawned'] = '¡Un Suministro Aéreo ha sido Desplegado!',

    -- Blip
    ['blip_name'] = 'Suministro Aéreo',
}